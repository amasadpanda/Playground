package search.game;

public class TicTacToeMove extends Move {
  public int moveIndex;
}
