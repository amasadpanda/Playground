package search.game;

abstract public class Move {
}
