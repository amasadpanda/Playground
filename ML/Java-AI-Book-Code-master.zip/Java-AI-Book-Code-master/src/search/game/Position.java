package search.game;

abstract public class Position {
}