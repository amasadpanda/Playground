package search.maze;

/**
 * Copyright Mark Watson 2008-2012. All Rights Reserved.
 */

public class Location {
    int x, y;
    public Location(int x, int y) { this.x = x; this.y = y; }

    public Location() {
    }
}
