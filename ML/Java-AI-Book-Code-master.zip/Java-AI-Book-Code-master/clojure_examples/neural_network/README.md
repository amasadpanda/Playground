# neural_network example backpropagation netowrk

This will compile the Java source files in the directory ../../src/neuralnetworks and add them to the project.

Run with:

~~~~~~~~
lein test
~~~~~~~~
