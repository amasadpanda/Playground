Open Source licenses for 3rd part libraries:

Drools Expert System Demos: Apache style license
PowerLoom Reasoning: LGPL
Sesame Semantic Web: LGPL
Weka: GPL


